<?php

use  App\Http\Controllers\StudentController;
use  App\Http\Controllers\AuthController;
use  App\Http\Controllers\PageController;

Route::middleware(['auth'])->group(function () {
    Route::get('students',[StudentController::class,'index']);
    Route::post('students',[StudentController::class,'store']);
    Route::get('fetch-students',[StudentController::class,'fetchstudent']);
    Route::get('edit-student/{id}',[StudentController::class,'edit']);
    Route::put('update-student/{id}',[StudentController::class,'update']);
    Route::delete('delete-student/{id}',[StudentController::class,'destroy']);
});

//Login and Register-----
Route::get('register',[AuthController::class,'registerview'])->name('registerview');
Route::get('/',[AuthController::class,'loginview'])->name('loginview');

Route::post('register',[AuthController::class,'register'])->name('register');
Route::post('/',[AuthController::class,'login'])->name('login');

//logout---
Route::get('logout',[AuthController::class,'logout'])->name('logout');
//Table Search Data---
Route::post('search',[StudentController::class,'search'])->name('search');