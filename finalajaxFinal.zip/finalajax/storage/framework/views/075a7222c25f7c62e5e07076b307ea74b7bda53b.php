<!doctype html>
<html lang="<?php echo e(str_replace('_', '-',app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', ' Laravel')); ?></title>

    <!-- <link href="<?php echo e(asset('frontend/css/bootstrap5.min.css')); ?>" rel="stylesheet"> -->
   
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
   
    <style>
        #page{
            background:#399918;
            font-size:20px;
            height:32px;
            width:60px;
            border:black 1px solid;
            border-radius:5px;
            color:white;
        }
    </style> <!-- <link href="<?php echo e(asset('frontend/css/custom.css')); ?>" rel="stylesheet"> -->
</head>
<body>

    <div id="app">
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

    </div>

    <!-- Scripts -->
    
    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH C:\wamp64\www\laravel\finalajax\resources\views/layouts/app.blade.php ENDPATH**/ ?>