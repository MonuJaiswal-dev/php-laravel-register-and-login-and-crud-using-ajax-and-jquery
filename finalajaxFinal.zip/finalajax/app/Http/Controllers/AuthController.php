<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{

    function registerview(){
        return view('register');
    }

    function loginview(){
        return view('login');
    }

    public function register(Request $request){
        //dd($request->all());
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'password' => 'required'
        ]);
        User::create([
        "name"=>$request->name,
        "email"=>$request->email,
        "password"=>\Hash::make($request->password)
        ]);
        if(\Auth::attempt($request->only('email','password'))){
            return redirect('/')->with('success','register sucess');
        }
        return redirect('login','again register');
    }

    public function login(Request $request){
        $request->validate([
            "email"=>'required',
            "password"=>'required'
            ]);
            if(\Auth::attempt($request->only('email','password'))){
                return redirect('students')->with('success','login sucess');
            }
            return redirect('/')->withError('message','again try'); 
        }
        function logout(){
        Auth::logout();
        return redirect('/');
        }       
}
